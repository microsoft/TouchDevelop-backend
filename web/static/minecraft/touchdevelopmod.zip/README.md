THIS SAMPLE MOD IS NOT OFFICIALLY SUPPORTED OR ENDORSED BY MICROSOFT. USE AND FORK AT YOUR OWN RISK.

# Touch Develop for Minecraft

A Minecraft Forge Mod that allows to use Touch Develop to code scripts for Minecraft.

## Using the mod

### Getting MCEF

Get MCEF and integrate it in the source base https://github.com/montoyo/mcef

### Installation:

0. Ensure you have JDK/JRE 1.6+ installed on your system.
1. Run a fresh installation of Minecraft on version 1.8.7 (or 1.8.8), exit once you see the main menu
2. Launch the "forge-1.8...installer-win" executable installer provided in the **drops** folder
3. Select "Install Client" and exit when installation complete
4. Navigate to root Minecraft directory (.minecraft), located in `%APPDATA%`
5. Copy all files from **drops/.minecraft** into the root Minecraft directory
6. Launch Minecraft, select and run **Forge** profile, enjoy!

### Getting started:

Simple! Just press `N` when in-game and the Touch Develop interface will appear on the right side of the Minecraft display. Create a new script of type 
"Minecraft," name it, and start coding!

### Demo Instructions:

1. Follow complete installation instructions above
2. Launch Minecraft, select "Singleplayer"
3. If "Demo World" already exists in world list, double click to launch. Otherwise, advance to step 4
4. Select "Create New World" and enter "Demo World" for the world name
5. Press the Game Mode button twice to switch it to "Creative"
6. Press "More World Options" and press the "World Type" button to change generation type to "Superflat."
7. Press "Done" and then "Create New World."

## Building the mod

### Updating Forge:

1. Go to files.minecraftforge.net in any browser
2. Scroll down, find "Download Recommended" box under "Downloads" (to right of "Download Latest")
3. Press "Installer-win" (Windows icon), wait 5 seconds for adfoc.us delay and then press red "Skip" button on top-right of page
4. Navigate back to "Download Recommended" box of files.minecraftforge.net, repeat step 3 for "Src" (brackets) instead of "Installer-Win"

This will give you updated, recommended builds of both the Forge installer for the actual Minecraft game and a new Forge development environment.
Note that you will need to repeat the Eclipse development instructions (below) for your new Forge source package.

### Development (Eclipse):

First and foremost, ensure you have JDK 1.6+ installed on your system and checkout TouchStudio repository from //codebox to known location.

1. Extract `forge-1.8...src` archive into a folder you intend to use for your development workspace
2. Open command line, change directory to workspace folder, run 'gradlew setupDecompWorkspace eclipse --refresh-dependencies'
3. Wait for process to finish, open Eclipse and select 'eclipse' project folder (in your forge directory) as workspace
4. File -> New -> Java Project, name "TouchDevelop" (unimportant), press 'Next'
5. Select 'Projects' tab, 'Add...', check Minecraft, 'OK,' press 'Finish'
6. In Package Explorer, right click 'src' folder and hit 'Delete'
7. Right-click 'TouchDevelop' in Package Explorer, New -> Folder, press 'Advanced >>', select 'Link to alternate location (Linked Folder)
8. Browse to `<touchstudio repo>\minecraft\src\main\java` as folder location, hit OK, press 'Finish'
9. Right-click just-created 'src' folder, New -> Source Folder, set name to 'src' to convert linked folder to linked source folder and hit OK
10. On top toolbar, press downward-facing arrow next to green 'Start' button, hit 'Run Configurations'
11. For first 'Client' entry, go to 'Classpath' tab, select 'User Entries', 'Add Projects'
12. On dialog, check 'TouchDevelop', unselect both checkboxes below to prevent redundant libraries, hit 'OK', hit 'Apply'
13. Repeat step 12 for first 'Server' entry
14. Make sure changes are applied and exit Run Configurations

You now have the TouchDevelop mod set up in your Eclipse workspace alongside the decompiled Minecraft libraries. All code changes will be made in your
touchstudio repository folder. Run the client by pressing the green start button. Happy coding!

### Building and packaging:

This assumes you already have set up your development environment as described above.

The easy way:

* open a command prompt under the `/mc` folder and run `build`. The script assumes that the mod folder is under `/gh/touchdevelop-mod`.

The long way:

0. Copy all your source files to the gradle folder
1. Open up Command Prompt and change directory to your Forge workspace folder (containing gradle, eclipse, build and src directories)
2. Run 'gradlew build' and wait for process to finish
3. In File Explorer, navigate to build/libs within your Forge workspace folder
4. Rename 'modid-1.0.jar' to 'TouchDevelop.jar'
5. Remove the src folder

This is the package placed in the 'mods' folder of your Minecraft installation.