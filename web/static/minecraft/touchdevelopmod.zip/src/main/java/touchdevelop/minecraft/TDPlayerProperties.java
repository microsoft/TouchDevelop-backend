package touchdevelop.minecraft;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.common.IExtendedEntityProperties;

public class TDPlayerProperties implements IExtendedEntityProperties
{
	public static final String ID = "TDPlayerProperties";
	
	public boolean firstLogin = true;
	
	public static void register(EntityPlayer player)
	{
		player.registerExtendedProperties(ID, new TDPlayerProperties());
	}
	
	@Override
	public void saveNBTData(NBTTagCompound compound) {}

	@Override
	public void loadNBTData(NBTTagCompound compound)
	{
		firstLogin = false;
	}

	@Override
	public void init(Entity entity, World world) {}
}
