package touchdevelop.minecraft;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.command.CommandException;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import touchdevelop.minecraft.client.TouchDevelopClient;

public class TouchDevelopCommand implements ICommand {
	private ArrayList aliases;
	
	public TouchDevelopCommand() {
		this.aliases = new ArrayList(); 
        this.aliases.add("touchdevelop"); 
        this.aliases.add("td"); 
        this.aliases.add("touchdev");
	}
	
	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public String getCommandUsage(ICommandSender sender) {
		return "open the TouchDevelop code editor";
	}
	
	@Override
	public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_) {
		return false;
	}
	
	@Override
	public String getName() {
		return "touchdevelop";
	}
	
	@Override
	public List getAliases() {
		return aliases;
	}
	
	@Override
	public void execute(ICommandSender sender, String[] args)
			throws CommandException {
		if (args.length == 0) {
			TouchDevelop.PROXY.showScreen();
			return;
		}
		
		String cmd = args[0];
		
		if(cmd.equalsIgnoreCase("local"))
		{
			if (TouchDevelop.remote) {
				TouchDevelop.remote = false;
				TouchDevelopClient.INSTANCE.loadHash("");
				sender.addChatMessage(new ChatComponentText("td: using localhost"));
			}
		}
		else if(cmd.equalsIgnoreCase("web"))
		{
			if (!TouchDevelop.remote) {
				TouchDevelop.remote = true;
				TouchDevelopClient.INSTANCE.loadHash("");
				sender.addChatMessage(new ChatComponentText("td: using touchdevelop.com"));		
			}
		}
		else if (cmd.equalsIgnoreCase("ip")) 
		{
			List<String> ips = this.getIpAddresses();
			for(int i = 0; i < ips.size(); ++i)
			sender.addChatMessage(new ChatComponentText("your computer LAN ip: " + ips.get(i)));
		}				
	}
	
	private List<String> getIpAddresses() {
		List<String> r= new ArrayList<String>();
		try {
			InetAddress inet = InetAddress.getLocalHost();
			InetAddress[] ips = InetAddress.getAllByName(inet.getCanonicalHostName());
			if (ips  != null ) {
				for (int i = 0; i < ips.length; i++) {
					if (!ips[i].isLoopbackAddress() && ips[i].isSiteLocalAddress())
						r.add(ips[i].getHostAddress());
				}				
			}
		} catch (UnknownHostException e) {}
		return r;
	}
	
	@Override
	public boolean canCommandSenderUse(ICommandSender sender) {
		return true;
	}
	
	@Override
	public List addTabCompletionOptions(ICommandSender sender, String[] args, BlockPos pos) {
		// TODO Auto-generated method stub
		return null;
	}
}
