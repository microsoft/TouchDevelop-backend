package touchdevelop.minecraft;

import java.io.IOException;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.montoyo.mcef.api.IBrowser;
import net.montoyo.mcef.api.MCEFApi;
import touchdevelop.minecraft.client.TouchDevelopClient;

public class BrowserScreen extends GuiScreen {

	public IBrowser browser = null;
	private float browserRatio = 0.45f;
	private GuiButton home = null;

	public void loadBrowser() {
		if (browser == null) {
			String url = TouchDevelop.TouchDevelopUrl("");			
			browser = MCEFApi.getAPI().createBrowser(url);
		}		
	}
	
	@Override
	public void initGui() {
		this.loadBrowser();
		// Resize the browser if window size changed
		if (browser != null) {
			browser.resize((int)(mc.displayWidth * this.browserRatio), mc.displayHeight);
		}

		// Create GUI
		Keyboard.enableRepeatEvents(true);
		buttonList.add(home = (new GuiButton(2, (int)(width * (1 - browserRatio) - 20), 0, 20, 20, "@")));
	}
	
	@Override
	public void drawScreen(int i1, int i2, float f) {
		// Render buttons
		super.drawScreen(i1, i2, f);
		this.drawBrowser();
	}
	
	public void drawBrowser() {
		// Renders the browser if itsn't null
		if (browser != null) {
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			browser.draw((int)(width * (1 - this.browserRatio)), height, width, 0.d); // Don't forget to flip
															// Y axis.
			GL11.glEnable(GL11.GL_DEPTH_TEST);
		}
	}	

	@Override
	public void onGuiClosed() {
		// Make sure to close the browser when you don't need it anymore.
		if (!TouchDevelopClient.INSTANCE.hasBackup() && browser != null)
		{
			String url = TouchDevelop.TouchDevelopUrl("");			
			browser.loadURL(url);
			browser.close();
		}

		Keyboard.enableRepeatEvents(false);
	}

	@Override
	public void handleInput() {
		while (Keyboard.next()) {
			boolean pressed = Keyboard.getEventKeyState();
			char key = Keyboard.getEventCharacter();
			int num = Keyboard.getEventKey();

			if (browser != null) { // Inject events into browser. TODO: Handle
									// keyboard mods.
				if (key != '.' && key != ';' && key != ',') { // Workaround
					if (pressed)
						browser.injectKeyPressed(key, 0);
					else
						browser.injectKeyReleased(key, 0);
				}

				if (key != Keyboard.CHAR_NONE)
					browser.injectKeyTyped(key, 0);
			}
		}
		
		while (Mouse.next()) {
			int btn = Mouse.getEventButton();
			boolean pressed = Mouse.getEventButtonState();
			int sx = Mouse.getEventX();
			int sy = Mouse.getEventY();
			int wheel = Mouse.getDWheel();

			if (browser != null) { // Inject events into browser. TODO: Handle
									// mods & leaving.
				int x = (int)(sx - mc.displayWidth * (1 - this.browserRatio));
				int y = mc.displayHeight - sy; // Don't forget to flip Y axis.
				if (x >= 0) {
					if (btn == -1)
						browser.injectMouseMove(x, y, 0, y < 0);
					else
						browser.injectMouseButton(x, y, 0, btn + 1, pressed, 1);
					if (wheel != 0)
						browser.injectMouseWheel(x, y, 0, wheel, 0);
				}
				else if (btn != -1 && !home.isMouseOver()) {
					this.hide();	
				}
			}

			if (pressed) { // Forward events to GUI.
				int x = sx * width / mc.displayWidth;
				int y = height - (sy * height / mc.displayHeight) - 1;

				try {
					mouseClicked(x, y, btn);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		this.drawBrowser();
	}

	public void onUrlChanged(IBrowser b, String nurl) {} // unused

	public void hide() 
	{
		TouchDevelopClient.INSTANCE.setBackup(this);
		mc.displayGuiScreen(null);		
	}
	
	// Handle button clicks
	@Override
	protected void actionPerformed(GuiButton src) {
		if (browser == null) return;
		if (src.id == 2) {
			String url = TouchDevelop.TouchDevelopUrl("");			
			this.browser.loadURL(url);
		}
	}

	@Override
    public boolean doesGuiPauseGame()
    {
        return false;
    }
}