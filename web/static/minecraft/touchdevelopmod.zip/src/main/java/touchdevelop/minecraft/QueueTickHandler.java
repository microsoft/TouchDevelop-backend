package touchdevelop.minecraft;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;
import touchdevelop.minecraft.mcpi.McpiCommands;
import touchdevelop.minecraft.mcpi.McpiMessage;
import touchdevelop.minecraft.mcpi.McpiMessage.PacketType;

public class QueueTickHandler {
	public static QueueTickHandler INSTANCE = new QueueTickHandler();

	// can change later
	private static final int QUEUE_THRESHOLD = 200;
	private static final int MAX_ITEM_PER_USER = 20;

	public LinkedList<ClientMessage> msgs = new LinkedList<ClientMessage>();
	public MinecraftServer server = MinecraftServer.getServer();

	@SubscribeEvent
	public void onTick(ServerTickEvent event) {
		if (event.phase == Phase.START) {
			int processed = 0;

			while (processed++ < QUEUE_THRESHOLD && msgs.size() > 0) {
				try {
					ClientMessage msg = msgs.pop(); // TODO: crash here
					if (msg != null) // not sure why it would be
					{
						World world = server.worldServerForDimension(msg.dimID);
	
						if (world != null && !world.isRemote) {
							EntityPlayerMP player = searchForPlayer(msg.username);
	
							if (player != null) {
								JsonElement query = new JsonParser().parse(msg.msg);
								JsonElement response = McpiCommands.ProcessServerCommand(player,  world,  query);
								TouchDevelop.INSTANCE.network.sendTo(
										new McpiMessage(PacketType.COMMAND).withCommand(response.toString()).withID(msg.msgID),
										player);
							}
						}
					}
				} catch(Exception ex) {
					msgs.clear();
				}
			}

			if (msgs.size() > 0) {
				TouchDevelop.INSTANCE.logger.warning(
						"TouchDevelop queue is overflowing, we still have " + msgs.size() + " messages to handle!");
			}
		}
	}

	public EntityPlayerMP searchForPlayer(String username) {
		for (WorldServer world : DimensionManager.getWorlds()) {
			for (EntityPlayerMP player : (List<EntityPlayerMP>) world.playerEntities) {
				if (player.getName().equals(username)) {
					return player;
				}
			}
		}

		return null;
	}

	public void receiveMessage(EntityPlayerMP player, ClientMessage msg) {
		// scan through and remove previous messages by user
		int itemPerUser = 0;
		for (Iterator<ClientMessage> iter = msgs.iterator(); iter.hasNext();) {
			ClientMessage iterMsg = iter.next();

			if (iterMsg.username.equals(msg.username) && itemPerUser++ > MAX_ITEM_PER_USER) {
				TouchDevelop.INSTANCE.network
						.sendTo(new McpiMessage(PacketType.COMMAND).withCommand("").withID(msg.msgID), player);
				System.out.println("TouchDevelop had to dump a repeat message by " + msg.username);
				return;
			}
		}

		msgs.add(msg);
	}

	public static class ClientMessage {
		// String ref to avoid holding onto player refs
		public String username;
		// dim ID ref for same reason
		public int dimID;
		public String msgID;
		public String msg;

		public ClientMessage(String name, int id, String s, String s1) {
			username = name;
			dimID = id;
			msgID = s;
			msg = s1;
		}
	}
}
