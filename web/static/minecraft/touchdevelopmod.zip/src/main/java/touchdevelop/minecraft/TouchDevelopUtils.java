package touchdevelop.minecraft;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.ForgeHooks;
import touchdevelop.minecraft.content.ItemScriptController;

public final class TouchDevelopUtils 
{
	public static void addOrEquip(EntityPlayer player, ItemStack stack)
	{
		for(int i = 0; i < player.inventory.getSizeInventory(); i++)
		{
			ItemStack iterStack = player.inventory.getStackInSlot(i);
			
			if(ItemStack.areItemStacksEqual(stack, iterStack))
			{
				//Move to equipped slot
				if(player.inventory.getCurrentItem() == null)
				{
					//Delete original, place in current slot
					player.inventory.setInventorySlotContents(i, null);
					player.inventory.setInventorySlotContents(player.inventory.currentItem, stack);
				}
				else {
					//Swap current slot with item in inventory
					ItemStack tmp = player.inventory.getCurrentItem();
					player.inventory.setInventorySlotContents(i, tmp);
					player.inventory.setInventorySlotContents(player.inventory.currentItem, stack);
				}
				
				//Swap complete!
				return;
			}
		}
		
		//Not in inventory
		
		if(player.inventory.getCurrentItem() != null)
		{
			//Try and clear up the current item slot
			ItemStack currentStack = player.inventory.getCurrentItem().copy();
			
			for(int i = 0; i < player.inventory.getSizeInventory(); i++)
			{
				if(i == player.inventory.currentItem)
				{
					continue;
				}
				
				if(player.inventory.getStackInSlot(i) == null)
				{
					//Slot is free, copy current item to slot
					player.inventory.setInventorySlotContents(i, currentStack);
					currentStack = null;
					break;
				}
				else if(player.inventory.getStackInSlot(i).isItemEqual(currentStack))
				{
					if(player.inventory.getStackInSlot(i).stackSize+currentStack.stackSize <= currentStack.getMaxStackSize())
					{
						player.inventory.getStackInSlot(i).stackSize += currentStack.stackSize;
						currentStack = null;
						break;
					}
					else {
						int total = player.inventory.getStackInSlot(i).stackSize+currentStack.stackSize;
						player.inventory.getStackInSlot(i).stackSize = Math.min(total, currentStack.getMaxStackSize());
						currentStack.stackSize = total-currentStack.getMaxStackSize();
					}
				}
			}
			
			if(currentStack != null)
			{
				//Drop current item otherwise
				ForgeHooks.onPlayerTossEvent(player, currentStack, false);
			}
		}
		
		//Finally, success ensured- set player inventory accordingly
		player.inventory.setInventorySlotContents(player.inventory.currentItem, stack);
		
		return;
	}
	
	public static ItemStack getPublishedController(String name, String script)
	{
		ItemStack stack = new ItemStack(TouchDevelopMod.publishedScriptController);
		
		((ItemScriptController)stack.getItem()).setName(stack, name);
		((ItemScriptController)stack.getItem()).setScript(stack, script);
		
		return stack;
	}
	
	public static void writeString(ByteBuf output, String s) 
	{ 
		output.writeInt(s.getBytes().length); 
		output.writeBytes(s.getBytes()); 
	} 
	 
	public static String readString(ByteBuf input) 
	{ 
		return new String(input.readBytes(input.readInt()).array()); 
	}

	public static void logToChat(EntityPlayer player, String text) 
	{
		player.addChatMessage(new ChatComponentText(text));
	}
}
