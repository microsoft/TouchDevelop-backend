package touchdevelop.minecraft;

import java.util.logging.Logger;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityEvent.EntityConstructing;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import touchdevelop.minecraft.content.ItemScriptController;
import touchdevelop.minecraft.mcpi.McpiMessage;
import touchdevelop.minecraft.mcpi.McpiMessageHandler;

@Mod(modid = TouchDevelop.MODID, version = TouchDevelop.VERSION, dependencies = "required-after:MCEF")
public class TouchDevelop 
{
	public static final String MODID = "touchdevelop";
	public static final String VERSION = "0.1";
	public static Logger logger = Logger.getLogger("TD");

	public static String LOCAL_URL = "http://localhost:4242/editor/local/";
	public static String REMOTE_URL = "https://www.touchdevelop.com/app/beta";
	
	public static boolean remote = true;

	public static String TouchDevelopUrl(String hash) 
	{
		return (remote ? REMOTE_URL : LOCAL_URL) + hash + "?theme=minecraft&noAnim=1" + (remote ? "" : "&dbg=1");
	}

	@Mod.Instance(MODID)
	public static TouchDevelop INSTANCE;

	@SidedProxy(serverSide = "touchdevelop.minecraft.CommonProxy", clientSide = "touchdevelop.minecraft.client.ClientProxy")
	public static CommonProxy PROXY;

	public static SimpleNetworkWrapper network;

	@EventHandler
	public void init(FMLPostInitializationEvent ev) 
	{
		PROXY.init(ev);
	}
	
	@EventHandler
	public void serverLoad(FMLServerStartingEvent event)
	{
		event.registerServerCommand(new TouchDevelopCommand());
	}
}