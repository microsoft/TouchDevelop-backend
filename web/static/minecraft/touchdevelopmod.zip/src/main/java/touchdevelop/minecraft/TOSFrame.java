package touchdevelop.minecraft;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class TOSFrame extends JFrame
{
	public TOSFrame(final Object sync)
	{
		this.setTitle("TouchDevelop Terms of Use");
		this.setSize(600, 700);
		this.getContentPane().setLayout(null);
		this.setResizable(false);
		
		JTextArea tosBox = new JTextArea();
		tosBox.setLocation(20, 20);
		tosBox.setSize(560, 520);
		tosBox.setVisible(true);
		tosBox.setEditable(false);
		tosBox.setText("Do you agree to load the Touch Develop editor in Minecraft?");
		
		this.getContentPane().add(tosBox);
		
		JButton accept = new JButton("Accept");
		accept.setLocation(20, 570);
		accept.setSize(270, 70);
		accept.requestFocus();
		accept.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				TOSFrame.this.dispose();
				
				synchronized(sync)
				{
					sync.notify();
				}
			}
		});
		
		this.getContentPane().add(accept);
		
		JButton decline = new JButton("Decline");
		decline.setLocation(600-20-270, 570);
		decline.setSize(270, 70);
		decline.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				TouchDevelopMod.INSTANCE.enabled = false;
				TOSFrame.this.dispose();
				
				synchronized(sync)
				{
					sync.notify();
				}
			}
		});
		
		this.getContentPane().add(decline);
		
		setVisible(true);
		
		try {
			synchronized(sync)
			{
				sync.wait();
			}
		} catch(Exception e) {}
	}
}
