package touchdevelop.minecraft.client;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.montoyo.mcef.api.IJSQueryCallback;
import touchdevelop.minecraft.TouchDevelop;
import touchdevelop.minecraft.mcpi.McpiMessage;
import touchdevelop.minecraft.mcpi.McpiMessage.PacketType;

/* This should only be used on the client side */
public class ClientMessageManager 
{
	public static ClientMessageManager INSTANCE = new ClientMessageManager();
	
	private static Minecraft mc = Minecraft.getMinecraft();
	
	public Map<String, MessageData> msgMap = new HashMap<String, MessageData>();
	public boolean shouldReset;
	
	public void newMessage(String query, IJSQueryCallback callback)
	{
		String id = genMsgID();
		
		McpiMessage msg = new McpiMessage(PacketType.COMMAND).withCommand(query).withID(id);
		TouchDevelop.INSTANCE.network.sendToServer(msg);
		
		msgMap.put(id, new MessageData(callback, query));
	}
	
	public void handleResponse(String id, String response)
	{
		if(msgMap.get(id) == null)
		{
			System.out.println("TouchDevelop received a response for an unknown command. Ignoring...");
			return;
		}
		
		msgMap.get(id).callback.success(response);
		msgMap.put(id, null);
	}
	
	public String genMsgID()
	{
		while(true)
		{
			String str = RandomStringUtils.randomAlphanumeric(8);
			
			for(String iter : msgMap.keySet())
			{
				if(iter.equals(str))
				{
					continue;
				}
			}
			
			return str;
		}
	}
	
	@SubscribeEvent
	public void onTick(ClientTickEvent event)
	{
		if(event.phase == Phase.START)
		{
			if(mc.theWorld != null)
			{
				shouldReset = true;
			}
			else if(shouldReset)
			{
				//if the world was just unloaded on the client side, dump msgs if exist
				int msgs = msgMap.size();
				
				if(msgs > 0)
				{
					System.out.println("TouchDevelop had to dump " + msgs + " messages while disconnecting.");
				}
				
				for(MessageData data : msgMap.values())
				{
					if (data != null)
						data.dump();
				}
				
				msgMap.clear();
				
				shouldReset = false;
			}
		}
	}
	
	public static class MessageData
	{
		public IJSQueryCallback callback;
		public String msg;
		
		public MessageData(IJSQueryCallback c, String s)
		{
			callback = c;
			msg = s;
		}
		
		public void dump()
		{
			callback.success("");
		}
	}
}
