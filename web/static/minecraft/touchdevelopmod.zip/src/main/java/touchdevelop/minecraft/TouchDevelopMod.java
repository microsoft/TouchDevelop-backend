package touchdevelop.minecraft;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityEvent.EntityConstructing;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import touchdevelop.minecraft.content.ItemScriptController;
import touchdevelop.minecraft.mcpi.McpiMessage;
import touchdevelop.minecraft.mcpi.McpiMessageHandler;

public class TouchDevelopMod
{
	public static TouchDevelopMod INSTANCE = new TouchDevelopMod();
	
	public boolean enabled = true;
	
	public static ItemScriptController localScriptController = (ItemScriptController)new ItemScriptController().setUnlocalizedName("LocalScriptController");
	public static ItemScriptController publishedScriptController = (ItemScriptController)new ItemScriptController().setUnlocalizedName("PublishedScriptController");

	public void init() 
	{
		if(enabled)
		{
			// Register key binding and listen to the FML event bus for ticks.
			FMLCommonHandler.instance().bus().register(QueueTickHandler.INSTANCE);
			MinecraftForge.EVENT_BUS.register(this);
			
			// Register script items
			registerItems();
			
			// Register network
			registerNetwork();
		}
	}
	
	private void registerItems()
	{
		GameRegistry.registerItem(localScriptController, "LocalScriptController");
		GameRegistry.registerItem(publishedScriptController, "PublishedScriptController");
	}
	
	private void registerNetwork() 
	{
		TouchDevelop.network = NetworkRegistry.INSTANCE.newSimpleChannel("TouchDevelop");
		TouchDevelop.network.registerMessage(McpiMessageHandler.class, McpiMessage.class, 0, Side.SERVER);
		TouchDevelop.network.registerMessage(McpiMessageHandler.class, McpiMessage.class, 0, Side.CLIENT);
	}
	
	@SubscribeEvent
	public void onEntityConstruct(EntityConstructing event)
	{
		if(event.entity instanceof EntityPlayer && !event.entity.worldObj.isRemote)
		{
			TDPlayerProperties.register((EntityPlayer)event.entity);
		}
	}
	
	@SubscribeEvent
	public void onEntityJoinWorld(EntityJoinWorldEvent event)
	{
		if(event.entity instanceof EntityPlayer && !event.entity.worldObj.isRemote)
		{
			EntityPlayer player = (EntityPlayer)event.entity;
			TDPlayerProperties props = (TDPlayerProperties)player.getExtendedProperties(TDPlayerProperties.ID);
			
			if(props.firstLogin)
			{
				player.addChatMessage(new ChatComponentText("Press 'N' to open the script editor."));
			}
		}
	}
}