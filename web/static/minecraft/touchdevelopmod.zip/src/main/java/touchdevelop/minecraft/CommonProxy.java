package touchdevelop.minecraft;

import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class CommonProxy 
{
	public void init(FMLPostInitializationEvent event) 
	{
		System.out.println("Called");
		TouchDevelopMod.INSTANCE.init();
	}
	
	//proxied because we don't want to reference client only stuff
	public void handleResponse(String id, String response) {}
	
	public void showScreen() {}
	
	public void runScript(String script) {}
	
	public void stopScript() {}
}