package touchdevelop.minecraft.mcpi;

import java.nio.charset.Charset;


import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import touchdevelop.minecraft.TouchDevelopUtils;

public class McpiMessage implements IMessage 
{
	public PacketType packetType;
	public String msgID;
	public String command;
	
	public McpiMessage(PacketType type)
	{
		packetType = type;
	}
	
	public McpiMessage() {} //For internal instantiation
	
	public McpiMessage withCommand(String s)
	{
		command = s;
		return this;
	}
	
	public McpiMessage withID(String id)
	{
		msgID = id;
		return this;
	}
	
	@Override
	public void fromBytes(ByteBuf buf) 
	{
		packetType = PacketType.values()[buf.readInt()];
		
		switch(packetType)
		{
			case COMMAND:
				msgID = TouchDevelopUtils.readString(buf);
				command = TouchDevelopUtils.readString(buf);
				break;
			default:
				break;
		}
	}

	@Override
	public void toBytes(ByteBuf buf) 
	{
		buf.writeInt(packetType.ordinal());
		
		switch(packetType)
		{
			case COMMAND:
				TouchDevelopUtils.writeString(buf, msgID);
				TouchDevelopUtils.writeString(buf, command);
				break;
			default:
				break;
		}
	}	
	
	public static enum PacketType
	{
		COMMAND,
		GUI_OPEN
	}
}
