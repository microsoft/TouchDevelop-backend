package touchdevelop.minecraft.mcpi;

import java.awt.AWTException;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.core.jmx.Server;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import net.minecraft.block.Block;
import net.minecraft.block.BlockCommandBlock;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;
import touchdevelop.minecraft.BrowserScreen;
import touchdevelop.minecraft.TouchDevelopUtils;
import touchdevelop.minecraft.client.TouchDevelopClient;

public class McpiCommands {
	public static String getString(JsonObject js, String elementName) {
		if (js.has(elementName))
			return js.get(elementName).getAsString();
		return null;
	}

	public static double getNumber(JsonObject js, String elementName) {
		if (js.has(elementName))
			return js.get(elementName).getAsDouble();
		return 0;
	}

	static JsonObject error(String msg) {
		JsonObject r = new JsonObject();
		r.addProperty("error", msg);
		return r;
	}

	public static JsonElement ProcessServerCommand(EntityPlayerMP player, World theWorld, JsonElement query) {
		if (query.isJsonArray()) {
			JsonArray ar = query.getAsJsonArray();
			JsonArray r = new JsonArray();
			for (int i = 0; i < ar.size(); ++i) {
				JsonObject c = processSingleServerCommand(player, theWorld, ar.get(i).getAsJsonObject());
				r.add(c);
			}
			return r;
		} else
			return processSingleServerCommand(player, theWorld, query.getAsJsonObject());
	}

	private static JsonObject processSingleServerCommand(EntityPlayerMP player, World theWorld, JsonObject query) {
		String cmd = getString(query, "name");
		if (cmd == null) {
			TouchDevelopUtils.logToChat(player, "! unknown command " + cmd);
			return null;
		}

		WorldInfo world = theWorld.getWorldInfo();

		// MISC
		// PLAYER COMMANDS
		if (cmd.equalsIgnoreCase("player.setPos")) {
			double x = getNumber(query, "x");
			double y = getNumber(query, "y");
			double z = getNumber(query, "z");
			player.setPositionAndUpdate(x, y, z);
			return new JsonObject();
		}
		// WORLD COMMANDS
		else if (cmd.equalsIgnoreCase("world.setBlock")) {
			int x = (int) getNumber(query, "x");
			int y = (int) getNumber(query, "y");
			int z = (int) getNumber(query, "z");

			y = Math.max(0, Math.min(theWorld.getActualHeight(), y));

			int bid = (int) getNumber(query, "id");
			int meta = (int) getNumber(query, "meta");
			int flag = 1 | 2; // Integer.parseInt(coords[5]);
			BlockPos pos = new BlockPos(x, y, z);
			Block block = Block.getBlockById(bid);
			IBlockState currentState = theWorld.getBlockState(pos);
			if (currentState.getBlock() != block) {
				if (bid == 0) {
					theWorld.destroyBlock(pos, false);
				} else {
					IBlockState state = meta == 0 ? block.getDefaultState() : block.getStateFromMeta(meta);
					theWorld.setBlockState(pos, state);
				}
			}
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("world.setBlocks")) {
			int x1 = (int) getNumber(query, "x1");
			int y1 = (int) getNumber(query, "y1");
			int z1 = (int) getNumber(query, "z1");
			int x2 = (int) getNumber(query, "x2");
			int y2 = (int) getNumber(query, "y2");
			int z2 = (int) getNumber(query, "z2");

			int bid = (int) getNumber(query, "id");
			int meta = (int) getNumber(query, "meta");
			int flag = 1 | 2; // Integer.parseInt(coords[5]);
			Block block = Block.getBlockById(bid);

			int sx = Math.min(x1, x2);
			int ex = Math.max(x1, x2);
			int sy = Math.max(0, Math.min(y1, y2));
			int ey = Math.min(theWorld.getActualHeight(), Math.max(y1, y2));
			int sz = Math.min(z1, z2);
			int ez = Math.max(z1, z2);

			for (int x = sx; x <= ex; ++x) {
				for (int y = sy; y <= ey; ++y) {
					for (int z = sz; z <= ez; ++z) {
						BlockPos pos = new BlockPos(x, y, z);
						IBlockState currentState = theWorld.getBlockState(pos);
						if (currentState.getBlock() != block) {
							if (bid == 0) {
								theWorld.setBlockToAir(new BlockPos(x, y, z));
							} else {
								IBlockState state = meta == 0 ? block.getDefaultState() : block.getStateFromMeta(meta);
								theWorld.setBlockState(pos, state);
							}
						}
					}
				}
			}
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("world.setCommand")) {
			int x = (int) getNumber(query, "x");
			int y = (int) getNumber(query, "y");
			int z = (int) getNumber(query, "z");

			y = Math.max(0, Math.min(theWorld.getActualHeight(), y));

			String command = getString(query, "cmd");
			BlockPos pos = new BlockPos(x, y, z);
			IBlockState currentState = theWorld.getBlockState(pos);

			TileEntity tile = theWorld.getTileEntity(pos);
			if (tile != null && tile instanceof TileEntityCommandBlock) {
				TileEntityCommandBlock tileCommand = (TileEntityCommandBlock) tile;
				CommandBlockLogic logic = tileCommand.getCommandBlockLogic();
				logic.setCommand(command);
				// TODO: looks like the block has be to trigger to make the
				// command
				// show in editor
			}
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("world.setWall")) {

			int x1 = (int) getNumber(query, "x1");
			int z1 = (int) getNumber(query, "z1");
			int x2 = (int) getNumber(query, "x2");
			int z2 = (int) getNumber(query, "z2");
			int h = (int) getNumber(query, "h");
			int bid = (int) getNumber(query, "id");
			int meta = (int) getNumber(query, "meta");
			int flag = 1 | 2; // Integer.parseInt(coords[7]);
			Block block = Block.getBlockById(bid);

			Block repeaterBlock = bid == 55 ? Block.getBlockById(94) : null;

			int sx = x1;
			int ex = x2;
			int sz = z1;
			int ez = z2;

			int maxy = theWorld.getActualHeight();

			int dx = Math.abs(ex - sx);
			int signx = (int) Math.signum(ex - sx);
			int dz = Math.abs(ez - sz);
			int signz = (int) Math.signum(ez - sz);
			int err = dx > dz ? dx / 2 : -dz / 2;

			int x = sx;
			int z = sz;
			int d = 0;
			int rdir = 0;
			do {
				// fill current wall
				int sy = getHeightValue(theWorld, x, z);
				int ey = Math.min(maxy, sy + h);

				for (int y = sy; y < ey; ++y) {
					BlockPos pos = new BlockPos(x, y, z);
					IBlockState currentState = theWorld.getBlockState(pos);
					if (d > 12 && repeaterBlock != null) {
						// time to add a repeater
						IBlockState state = repeaterBlock.getStateFromMeta(rdir);
						theWorld.setBlockState(pos, state);
						d = 1;

						// we need to add a wire on the opposite side of the
						// repeater
						// and keep creating the line from there
						switch (rdir) {
						case 0:
							z -= 1;
							break;
						case 1:
							x += 1;
							break;
						case 2:
							z += 1;
							break;
						case 3:
							x -= 1;
							break;
						}
						// reset line search
						dx = Math.abs(ex - x);
						signx = (int) Math.signum(ex - x);
						dz = Math.abs(ez - z);
						signz = (int) Math.signum(ez - z);
						err = dx > dz ? dx / 2 : -dz / 2;
					} else if (currentState.getBlock() != block) {
						if (bid == 0) {
							theWorld.setBlockToAir(new BlockPos(x, y, z));
						} else {
							IBlockState state = meta == 0 ? block.getDefaultState() : block.getStateFromMeta(meta);
							theWorld.setBlockState(pos, state);
						}

						int e2 = err;
						if (e2 > -dx) {
							err -= dz;
							x += signx;
							rdir = signx > 0 ? 1 : 3;
						} else if (e2 < dz) {
							err += dx;
							z += signz;
							rdir = signz > 0 ? 2 : 0;
						}
						d++;
					}
				}
			} while (x != ex || z != ez);

			return new JsonObject();
		}
		// ENTITY
		else if (cmd.equalsIgnoreCase("entity.getPos")) {
			int id = (int) getNumber(query, "id");
			Entity entity = findEntity(theWorld, id);
			if (entity == null)
				return error("entity not found");

			double x = entity.posX;
			double y = entity.posY;
			double z = entity.posZ;
			JsonObject r = new JsonObject();
			r.addProperty("x", x);
			r.addProperty("y", y);
			r.addProperty("z", z);
			return r;
		} else if (cmd.equalsIgnoreCase("entity.setPos")) {
			int id = (int) getNumber(query, "id");
			Entity entity = findEntity(theWorld, id);
			if (entity == null)
				return error("entity not found");

			double x = getNumber(query, "x");
			double y = getNumber(query, "y");
			double z = getNumber(query, "z");

			entity.setPositionAndUpdate(x, y, z);
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("entity.spawn")) {
			String kind = getString(query, "kind");
			double x = getNumber(query, "x");
			double y = getNumber(query, "y");
			double z = getNumber(query, "z");
			Entity entity;
			if (kind.equalsIgnoreCase("sheep"))
				entity = new EntitySheep(theWorld);
			else
				entity = new EntityCreeper(theWorld);

			entity.setPosition(x, y, z);
			if (!theWorld.spawnEntityInWorld(entity)) {
				TouchDevelopUtils.logToChat(player, "entity spawn failed");
				return error("spawn failed");
			}
			JsonObject r = new JsonObject();
			r.addProperty("id", entity.getEntityId());
			return r;
		}
		// MISC
		else if (cmd.equalsIgnoreCase("chat.post")) {
			String msg = getString(query, "msg");
			player.addChatMessage(new ChatComponentText(msg));
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("touchdevelop.script")) {
			String name = getString(query, "name");
			String id = getString(query, "id");
			TouchDevelopUtils.addOrEquip(player, TouchDevelopUtils.getPublishedController(name, id));
			return new JsonObject();
			// OPS
		} else {
			TouchDevelopUtils.logToChat(player, "unknown command: " + cmd);
			return new JsonObject();
		}
	}

	public static JsonElement ProcessClientCommand(TouchDevelopClient client, EntityPlayerSP player, World theWorld,
			JsonObject query) throws AWTException, IOException {
		if (query.isJsonArray()) {
			JsonArray ar = query.getAsJsonArray();
			JsonArray r = new JsonArray();
			for (int i = 0; i < ar.size(); ++i) {
				JsonObject c = processSingleClientCommand(client, player, theWorld, ar.get(i).getAsJsonObject());
				r.add(c);
			}
			return r;
		} else
			return processSingleClientCommand(client, player, theWorld, query.getAsJsonObject());
	}

	private static JsonObject processSingleClientCommand(TouchDevelopClient client, EntityPlayerSP player,
			World theWorld, JsonObject query) throws AWTException, IOException {
		String cmd = getString(query, "name");
		if (cmd == null) {
			TouchDevelopUtils.logToChat(player, "! unknown command " + cmd);
			return null;
		}

		if (cmd.equalsIgnoreCase("player.getPos")) {
			// ignore user name
			double x = player.posX;
			double y = player.posY;
			double z = player.posZ;
			JsonObject r = new JsonObject();
			r.addProperty("x", x);
			r.addProperty("y", y);
			r.addProperty("z", z);
			return r;
		} else if (cmd.equalsIgnoreCase("world.getHeight")) {
			int x = (int) getNumber(query, "x");
			int z = (int) getNumber(query, "z");
			int y = getHeightValue(theWorld, x, z);
			JsonObject r = new JsonObject();
			r.addProperty("h", y);
			return r;
		} else if (cmd.equalsIgnoreCase("world.getBlock")) {
			int x = (int) getNumber(query, "x");
			int y = (int) getNumber(query, "y");
			int z = (int) getNumber(query, "z");
			Block block = theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
			JsonObject r = new JsonObject();
			r.addProperty("id", Block.getIdFromBlock(block));
			return r;
		} else if (cmd.equalsIgnoreCase("version")) {
			JsonObject r = new JsonObject();
			r.addProperty("v", "2.0");
			return r;
		} else if (cmd.equalsIgnoreCase("screen.min")) {
			Minecraft mc = Minecraft.getMinecraft();
			if ((mc.currentScreen instanceof BrowserScreen)) {
				((BrowserScreen) mc.currentScreen).hide();
				try {
					mc.updateDisplay();
				} catch (Exception ex) {
				}
			}
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("screen.show")) {
			Minecraft mc = Minecraft.getMinecraft();
			if (!(mc.currentScreen instanceof BrowserScreen))
				client.showScreen();
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("screen.screenshot")) {
			String url = client.takeScreenshot();
			JsonObject r = new JsonObject();
			r.addProperty("url", url);
			return r;
		} else if (cmd.equalsIgnoreCase("chat.send")) {
			String msg = getString(query, "msg");
			Minecraft.getMinecraft().thePlayer.sendChatMessage(msg);
			return new JsonObject();
		} else if (cmd.equalsIgnoreCase("player.name")) {
			JsonObject r = new JsonObject();
			r.addProperty("name", player.getDisplayNameString());
			return r;
		} else
			// server command
			return null;
	}

	static Entity findEntity(World theWorld, int id) {
		Entity entity = theWorld.getEntityByID(id);
		if (entity != null)
			return entity;

		for (int i = 0; i < theWorld.loadedEntityList.size(); ++i) {
			Entity et = (Entity) theWorld.loadedEntityList.get(i);
			if (et.getEntityId() == id)
				return et;
		}
		return null;
	}

	/**
	 * Finds the topmost block position at an X, Z position in the world
	 * 
	 * @param parWorld
	 * @param parX
	 * @param parZ
	 * @return
	 */
	static int getHeightValue(World parWorld, int intX, int intZ) {
		int chunkX = intX >> 4;
		int chunkZ = intZ >> 4;
		int height = parWorld.getChunkFromChunkCoords(chunkX, chunkZ).getHeight(intX & 15, intZ & 15);

		return height;
	}
}
