package touchdevelop.minecraft.mcpi;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import touchdevelop.minecraft.QueueTickHandler;
import touchdevelop.minecraft.QueueTickHandler.ClientMessage;
import touchdevelop.minecraft.TouchDevelop;
import touchdevelop.minecraft.TouchDevelopMod;
import touchdevelop.minecraft.TouchDevelopUtils;

public class McpiMessageHandler implements IMessageHandler<McpiMessage, McpiMessage> {
	@Override
	public McpiMessage onMessage(McpiMessage message, MessageContext ctx) 
	{
		if(ctx.side == Side.SERVER)
		{
			EntityPlayerMP player = ctx.getServerHandler().playerEntity;
			World theWorld = MinecraftServer.getServer().worldServerForDimension(player.dimension);
			
			switch(message.packetType)
			{
				case COMMAND:
					QueueTickHandler.INSTANCE.receiveMessage(player, new ClientMessage(player.getName(), theWorld.provider.getDimensionId(), message.msgID, message.command));
					break;
				case GUI_OPEN:
					TouchDevelopUtils.addOrEquip(player, new ItemStack(TouchDevelopMod.localScriptController));
					break;
				default:
					break;
			}
			
			return null;
		}
		else {
			TouchDevelop.INSTANCE.PROXY.handleResponse(message.msgID, message.command);
			
			return null;
		}
	}
}
