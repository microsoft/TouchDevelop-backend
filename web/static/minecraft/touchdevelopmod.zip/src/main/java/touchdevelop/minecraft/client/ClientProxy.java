package touchdevelop.minecraft.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import touchdevelop.minecraft.CommonProxy;
import touchdevelop.minecraft.TOSFrame;
import touchdevelop.minecraft.TouchDevelop;
import touchdevelop.minecraft.TouchDevelopMod;

public class ClientProxy extends CommonProxy 
{	
	@Override
	public void init(FMLPostInitializationEvent event) 
	{
		super.init(event);
		
		if(TouchDevelopMod.INSTANCE.enabled)
		{
			TouchDevelopClient.INSTANCE.init();
			
			RenderItem renderItem = Minecraft.getMinecraft().getRenderItem();
			renderItem.getItemModelMesher().register(TouchDevelopMod.localScriptController, 0, new ModelResourceLocation(TouchDevelop.MODID + ":LocalScriptController", "inventory"));
			renderItem.getItemModelMesher().register(TouchDevelopMod.publishedScriptController, 0, new ModelResourceLocation(TouchDevelop.MODID + ":PublishedScriptController", "inventory"));
			
			FMLCommonHandler.instance().bus().register(ClientMessageManager.INSTANCE);
		}
	}
	
	@Override
	public void handleResponse(String id, String response)
	{
		ClientMessageManager.INSTANCE.handleResponse(id, response);
	}
	
	@Override
	public void showScreen() 
	{
		TouchDevelopClient.INSTANCE.showScreen();
	}
	
	@Override
	public void runScript(String script) 
	{
		TouchDevelopClient.INSTANCE.notifyRun(script);
	}
	
	@Override
	public void stopScript()
	{
		TouchDevelopClient.INSTANCE.notifyStop();
	}
}
