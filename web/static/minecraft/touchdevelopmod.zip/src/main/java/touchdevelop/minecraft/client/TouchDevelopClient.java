package touchdevelop.minecraft.client;

import java.awt.AWTException;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

import javax.imageio.ImageIO;
import javax.xml.bind.DatatypeConverter;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.montoyo.mcef.api.API;
import net.montoyo.mcef.api.IBrowser;
import net.montoyo.mcef.api.IDisplayHandler;
import net.montoyo.mcef.api.IJSQueryCallback;
import net.montoyo.mcef.api.IJSQueryHandler;
import net.montoyo.mcef.api.MCEFApi;
import touchdevelop.minecraft.BrowserScreen;
import touchdevelop.minecraft.TouchDevelop;
import touchdevelop.minecraft.TouchDevelopMod;
import touchdevelop.minecraft.TouchDevelopUtils;
import touchdevelop.minecraft.mcpi.McpiCommands;
import touchdevelop.minecraft.mcpi.McpiMessage;
import touchdevelop.minecraft.mcpi.McpiMessage.PacketType;

//Client-only stuff
public class TouchDevelopClient implements IDisplayHandler, IJSQueryHandler {
	public static TouchDevelopClient INSTANCE = new TouchDevelopClient();

	private KeyBinding keyOpen = new KeyBinding("TouchDevelop.Editor", Keyboard.KEY_N, "key.categories.misc");
	private Minecraft mc = Minecraft.getMinecraft();
	private BrowserScreen backup = null;
	protected Path lastScreenshot = null;

	public void init() {
		// Register for Forge events (client ticks)
		FMLCommonHandler.instance().bus().register(this);

		// Register open key binding
		ClientRegistry.registerKeyBinding(keyOpen);

		// Grab the API and make sure it isn't null.
		API api = MCEFApi.getAPI();

		// Register this class to handle onAddressChange and onQuery events
		api.registerDisplayHandler(this);
		api.registerJSQueryHandler(this);

		// Load browser in background
		BrowserScreen screen = new BrowserScreen();
		screen.loadBrowser();
		this.setBackup(screen);

		// watch screenshot folder
		this.watchScreenshots();
	}

	@SubscribeEvent
	public void onTick(TickEvent ev) {
		if (ev.phase == TickEvent.Phase.START && ev.side == Side.CLIENT && ev.type == TickEvent.Type.CLIENT) {
			// Check if our key was pressed

			if (mc.theWorld != null) {
				if (keyOpen.isPressed())
					this.showScreen();
			}
		}
	}

	public void loadHash(String hash) {
		this.showScreen();
		if (hash != null) {
			IBrowser b = this.getBrowser();
			if (b != null)
				b.loadURL(TouchDevelop.TouchDevelopUrl(hash));
		}
	}

	private void notifyTakeScreenshot() {
		IBrowser b = this.getBrowser();
		if (b != null) {
			try {
				b.runJS("TDev.TheEditor.host.takeScreenshot()", "");
			} catch (Exception ex) {

			}
		}
	}

	// notifies hosted editor to run a script
	public void notifyRun(String scriptid) {
		IBrowser b = this.getBrowser();

		if (b != null) {
			try {
				b.runJS("TDev.TheEditor.host.runByScriptId(\"" + (scriptid == null ? "" : scriptid) + "\")", "");
			} catch (Exception ex) {
			}
		}
	}

	// notifies hosted editor to stop a script
	public void notifyStop() {
		IBrowser b = this.getBrowser();

		if (b != null) {
			try {
				b.runJS("TDev.TheEditor.host.stopRun()", "");
			} catch (Exception ex) {
			}
		}
	}

	@Override
	public void onAddressChange(IBrowser browser, String url) {
		// Called by MCEF if a browser's URL changes. Forward this event to the
		// screen.
		if (mc.currentScreen instanceof BrowserScreen)
			((BrowserScreen) mc.currentScreen).onUrlChanged(browser, url);
		else if (hasBackup())
			backup.onUrlChanged(browser, url);
	}

	@Override
	public void onTitleChange(IBrowser browser, String title) {
	}

	@Override
	public boolean onTooltip(IBrowser browser, String text) {
		return false;
	}

	@Override
	public void onStatusMessage(IBrowser browser, String value) {
	}

	@Override
	public boolean onConsoleMessage(IBrowser browser, String message, String source, int line) {
		//
		return false;
	}

	@Override
	public boolean handleQuery(IBrowser b, long queryId, String query, boolean persistent, IJSQueryCallback cb) {
		if (b == getBrowser()) {
			try {				
				JsonElement msg = new JsonParser().parse(query);
				if (msg.isJsonPrimitive() && ((JsonPrimitive)msg).isString())
				{
					JsonObject m = new JsonObject();
					m.addProperty("name", msg.getAsString());
					msg = m;
				}
				JsonElement clientResponse = msg.isJsonObject()
						? McpiCommands.ProcessClientCommand(this, mc.thePlayer, mc.theWorld, msg.getAsJsonObject())
						: null;

				// check if the client didn't handle the message
				if (clientResponse == null) {
					ClientMessageManager.INSTANCE.newMessage(query, cb);
				} else {
					// otherwise we can call success right away
					cb.success(clientResponse == null ? "" : clientResponse.toString());
				}
			} catch (Throwable t) {
				TouchDevelopUtils.logToChat(mc.thePlayer, t.toString());
				StackTraceElement[] st = t.getStackTrace();
				for (int i = 0; i < Math.min(3, st.length); ++i)
					TouchDevelopUtils.logToChat(mc.thePlayer, st[i].toString());
				cb.failure(500, t.getMessage());
				t.printStackTrace();
			}

			return true;
		}

		return false;
	}

	public String takeScreenshot() throws AWTException, IOException {
		final int maxSize = 1024;

		Path p = lastScreenshot;
		lastScreenshot = null;
		BufferedImage image = null;
		if (p != null) {
			// the file might still be written to disk
			for (int i = 0; i < 3; ++i)
				try {
					image = ImageIO.read(p.toFile());
					break;
				} catch (Exception ex) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						break;
					}
				}
		}

		if (image == null) {
			image = new Robot().createScreenCapture(
					new Rectangle(Display.getX() + 8, Display.getY() + 30, Display.getWidth(), Display.getHeight()));
		}

		// resize as needed
		if (image.getHeight() > maxSize || image.getWidth() > maxSize) {
			int w, h;
			if (image.getWidth() > image.getHeight()) {
				w = maxSize;
				h = (int) (maxSize / (double) image.getWidth() * image.getHeight());
			} else {
				h = maxSize;
				w = (int) (maxSize / (double) image.getHeight() * image.getWidth());
			}
			BufferedImage small = new BufferedImage(w, h, BufferedImage.TYPE_INT_BGR);
			Graphics g = small.getGraphics();
			g.drawImage(image, 0, 0, w, h, null);
			g.dispose();

			image = small;
		}

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		ImageIO.setUseCache(false);
		ImageIO.write(image, "jpg", stream);
		byte[] bytes = stream.toByteArray();
		String imgString = "data:image/jpeg;base64," + DatatypeConverter.printBase64Binary(bytes);
		return imgString;
	}

	@Override
	public void cancelQuery(IBrowser b, long queryId) {
	}

	private void watchScreenshots() {
		try {
			Path dir = Paths.get(mc.mcDataDir.getPath(), "screenshots");
			if (dir.toFile().isDirectory()) {
				WatchService watcher = FileSystems.getDefault().newWatchService();
				dir.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
				WatchQueueReader fileWatcher = new WatchQueueReader(this, watcher, dir);
				Thread th = new Thread(fileWatcher, "FileWatcher");
				th.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static class WatchQueueReader implements Runnable {
		private TouchDevelopClient parent;
		private WatchService myWatcher;
		private Path dir;

		public WatchQueueReader(TouchDevelopClient parent, WatchService myWatcher, Path dir) {
			this.parent = parent;
			this.myWatcher = myWatcher;
			this.dir = dir;
		}

		@Override
		public void run() {
			try {
				// get the first event before looping
				WatchKey key = myWatcher.take();
				while (key != null) {
					// we have a polled event, now we traverse it and
					// receive all the states from it
					for (WatchEvent event : key.pollEvents()) {
						if (event.kind() != StandardWatchEventKinds.ENTRY_CREATE)
							continue;
						WatchEvent<Path> ev = (WatchEvent<Path>) event;
						Path fn = ev.context();
						Thread.sleep(500); // give time to system to write file
						this.parent.lastScreenshot = Paths.get(dir.toString(), fn.toString());
						this.parent.notifyTakeScreenshot();
					}
					if (!key.reset())
						break;
					key = myWatcher.take();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void setBackup(BrowserScreen bu) {
		backup = bu;
	}

	public boolean hasBackup() {
		return (backup != null);
	}

	public IBrowser getBrowser() {
		if (mc.currentScreen instanceof BrowserScreen)
			return ((BrowserScreen) mc.currentScreen).browser;
		else if (backup != null)
			return backup.browser;
		else
			return null;
	}

	public void showScreen() {
		if (!(mc.currentScreen instanceof BrowserScreen)) {
			// Display the web browser UI.
			mc.displayGuiScreen(hasBackup() ? backup : new BrowserScreen());
			backup = null;

			TouchDevelopUtils.addOrEquip(mc.thePlayer, new ItemStack(TouchDevelopMod.localScriptController));
			TouchDevelop.INSTANCE.network.sendToServer(new McpiMessage(PacketType.GUI_OPEN));
		}
	}
}
